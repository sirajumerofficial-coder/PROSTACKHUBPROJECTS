# LibraryDesk - A Library Management System

LibraryDesk is a desktop application (Java Swing) for managing a small library. The librarian can add books, issue a book to a student for a chosen number of days, accept returns, and see which student holds which book. A late fee is calculated automatically when a book is returned after its due date. The full library state is saved in files and reloaded on the next run.

## Features

- Add books (title, author, ISBN, number of copies). Adding an existing ISBN increases its copies
- Issue a book to a student with an issue date and "days to keep"
- Accept returns and calculate the late fee (late days x fine per day)
- Block issuing when a book has zero copies available
- Track which student holds which book, with issue date and due date
- Configurable default days to keep and fine per day (Settings tab)
- Whole library state is saved to files and reloaded on restart
- Book selection through a dropdown list, input validation and error dialogs

## Tech used

- Java (JDK 8 or higher)
- Swing (`JFrame`, `JTabbedPane`, `JTable`, `JComboBox`, `JOptionPane`)
- `ArrayList`, `LocalDate` (java.time), file handling (`File`, `Scanner`, `PrintWriter`)
- Object-oriented design with separate classes

## Project structure

```
LibraryDesk/
 ├── Main.java                 Starts the application window
 ├── LibraryGUI.java           The window: tabs, buttons, tables
 ├── LibraryManagement.java    Library logic and file handling
 ├── Book.java                 Data of one book
 ├── IssuedBookRecord.java     Which student holds which book, issue and due date
 ├── books.txt                 Created automatically (isbn,title,author,copies)
 ├── issued.txt                Created automatically (studentId,isbn,issueDate,dueDate)
 └── settings.txt              Created automatically (default days,fine per day)
```

## Architecture

| Class | Responsibility | Main data | Main methods |
|---|---|---|---|
| `Book` | Holds one book | `title`, `author`, `isbn`, `availableCopies` | `issueOneCopy()`, `returnOneCopy()`, `addCopies()` |
| `IssuedBookRecord` | Holds one issued book | `studentId`, `isbn`, `issueDate`, `dueDate` | getters, `toFileLine()` |
| `LibraryManagement` | All library logic, file saving/loading | `ArrayList<Book>`, `ArrayList<IssuedBookRecord>`, `allowedDays`, `finePerDay` | `addBook()`, `searchBook()`, `issueBook()`, `returnBook()`, `calculateLateFee()` |
| `LibraryGUI` | The Swing window with 4 tabs | tables, text fields, dropdown | `buildBooksTab()`, `buildIssueTab()`, `refreshTables()` |
| `Main` | Starts the GUI | none | `main()` |

### Late fee

```
dueDate  = issueDate + daysToKeep
lateDays = returnDate - dueDate
fee      = lateDays x finePerDay      (0 if returned on time)
```

### Program flow

1. Program starts and loads `settings.txt`, `books.txt` and `issued.txt`
2. Books tab: add books and see the list of all books
3. Issue / Return tab: select a book, enter student ID, date and days to keep, then Issue or Return
4. Issuing is blocked if the book has no copies available
5. Return shows days kept, due date and late fee
6. Issued Books tab: shows who holds which book with issue and due dates
7. Every change is saved to the files immediately

## How to run

1. Install the JDK (version 8 or higher)
2. Keep all files in one folder and open a terminal there
3. Compile and run:

```
javac *.java
java Main
```

Dates must be written as `yyyy-mm-dd` with two digits for month and day, for example `2026-10-05`.

## Screenshots

### Books tab (list of books and the form to add a new book)
![Books tab](screenshots/01-books-tab.png)

### Issuing a book (select the book from the dropdown, enter the days to keep; the confirmation shows the due date)
![Issuing a book](screenshots/02-issue-book.png)

### Issued Books tab (which student holds which book, with issue and due date)
![Issued books](screenshots/03-issued-books.png)

### Returning a book after the due date (late days and late fee are calculated automatically)
![Late fee](screenshots/04-late-fee.png)

### Last copy issued (the dropdown now shows 0 copies available)
![Last copy issued](screenshots/05-last-copy-issued.png)

### Issuing is blocked when no copies are available
![No copies available](screenshots/06-no-copies.png)

### Settings tab (default days to keep and fine per late day)
![Settings](screenshots/07-settings.png)

## Author

Siraj Ul Umer
