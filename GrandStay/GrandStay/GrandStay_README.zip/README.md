# GrandStay - A Hotel Booking Platform

GrandStay is a console-based hotel booking system written in Java. A user can search available rooms by type and date, book a room for a guest, cancel a reservation, and generate a bill. Rooms and reservations are saved in files, so everything is reloaded correctly when the program is started again.

## Features

- Search available rooms by type (Standard / Deluxe / Suite) and date range
- Book a room for a guest. The room becomes unavailable for those dates (overlapping bookings are blocked)
- Cancel a reservation, which frees the room again
- Generate a simple bill: price per night x nights stayed
- Show all reservations
- Rooms and reservations are saved to files and reloaded on restart
- Input validation for dates, room type and numbers

## Tech used

- Java (JDK 8 or higher)
- `ArrayList`, `Scanner`, `LocalDate` (java.time), file handling (`File`, `PrintWriter`)
- Object-oriented design with separate classes

## Project structure

```
GrandStay/
 ├── Main.java             Menu and user input
 ├── Hotel.java            Booking logic and file handling
 ├── Room.java             Data of one room
 ├── Reservation.java      Data of one reservation
 ├── rooms.txt             Created automatically on first run (8 default rooms)
 └── reservations.txt      Created automatically after the first booking
```

## Architecture

| Class | Responsibility | Main data | Main methods |
|---|---|---|---|
| `Room` | Holds one room | `number`, `type`, `price` | getters |
| `Reservation` | Holds one booking | `id`, `guestName`, `roomNumber`, `checkIn`, `checkOut` | `getNights()`, `toFileLine()` |
| `Hotel` | All hotel logic and file saving/loading | `ArrayList<Room>`, `ArrayList<Reservation>`, `nextId` | `searchAvailable()`, `bookRoom()`, `cancelReservation()`, `printBill()`, `isRoomFree()` |
| `Main` | Menu and input helpers | `Scanner`, `Hotel` | `main()`, `readDate()`, `readType()` |

### How availability works

A room is not free if an existing reservation of that room overlaps the new dates:

```
newCheckIn < existingCheckOut   AND   newCheckOut > existingCheckIn
```

Because of this, a guest can check in on the same day another guest checks out.

### Program flow

1. Program starts, loads `rooms.txt` and `reservations.txt` (default rooms are created on the first run)
2. Menu: Search / Book / Cancel / Bill / Show all reservations / Exit
3. Search: enter type and dates, available rooms are listed
4. Book: choose a room from the list, enter guest name, a reservation ID is given and saved
5. Cancel: enter reservation ID, the record is removed and saved
6. Bill: enter reservation ID, total = price per night x nights

## Default rooms

| Rooms | Type | Price per night |
|---|---|---|
| 101, 102, 103 | Standard | Rs. 5000 |
| 201, 202, 203 | Deluxe | Rs. 8000 |
| 301, 302 | Suite | Rs. 15000 |

You can change rooms and prices by editing `rooms.txt` (format: `roomNumber,type,price`).

## How to run

1. Install the JDK (version 8 or higher)
2. Keep all files in one folder and open a terminal there
3. Compile and run:

```
javac *.java
java Main
```

Dates must be written as `yyyy-mm-dd` with two digits for month and day, for example `2026-10-05`.

## Screenshots

### Booking a room (enter type and dates, the available rooms are listed, then choose a room and enter the guest name)
![Search and booking](screenshots/01-search-and-booking.png)

## Author

Siraj Ul Umer
