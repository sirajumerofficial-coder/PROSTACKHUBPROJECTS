# QuizMaster - A Quiz Practice Platform

QuizMaster is a console-based quiz application written in Java. Questions are loaded from a CSV file (nothing is hardcoded), the user picks a category, answers multiple-choice questions, gets instant feedback with a live score, and sees a final result screen. Scores are saved to a file, so the leaderboard is still there the next time the program runs.

## Features

- Loads multiple-choice questions from `questions.csv` (add new questions without changing the code)
- 3 categories (Java, Science, GK), selectable before the quiz starts
- Live score with correct/incorrect feedback after every question
- Final results screen with score, percentage and the questions the user missed (with correct answers)
- Persistent leaderboard saved in `leaderboard.txt`, sorted by percentage (Top 10 shown)
- Input validation (only A, B, C or D is accepted as an answer)

## Tech used

- Java (JDK 8 or higher)
- `ArrayList`, `Scanner`, file handling (`File`, `PrintWriter`)
- Object-oriented design with separate classes

## Project structure

```
QuizMaster/
 ├── Main.java            Menu and program start
 ├── Question.java        Data of one question
 ├── QuizManager.java     Loads questions from the CSV file
 ├── Quiz.java            Runs one quiz session
 ├── Leaderboard.java     Saves and loads high scores
 ├── questions.csv        Question bank
 └── leaderboard.txt      Created automatically after the first quiz
```

## Architecture

| Class | Responsibility | Main data | Main methods |
|---|---|---|---|
| `Question` | Holds one question | `category`, `text`, `options[]`, `correct` | `isCorrect()`, `getCorrectText()` |
| `QuizManager` | Reads the CSV file and filters by category | `ArrayList<Question>` | `loadQuestions()`, `getCategories()`, `getQuestionsByCategory()` |
| `Quiz` | Runs the quiz, tracks score and missed questions | `score`, `questions`, `missed` | `start()`, `showResults()`, `getPercentage()` |
| `Leaderboard` | Stores scores in a file and sorts them | `ArrayList<String[]>` | `addScore()`, `display()`, `load()`, `save()` |
| `Main` | Menu (Play / Leaderboard / Exit) | `Scanner` | `main()`, `playQuiz()` |

### Program flow

1. Program starts and loads `questions.csv`
2. Main menu: Play Quiz / View Leaderboard / Exit
3. User selects a category and enters a name
4. Questions are shown one by one, with feedback and live score after each answer
5. Final results are displayed (score, percentage, missed questions)
6. Score is saved to `leaderboard.txt` and the user returns to the menu

## questions.csv format

One question per line, 7 values separated by commas:

```
category,question,optionA,optionB,optionC,optionD,correctLetter
```

Do not use a comma inside a question or an option.

## How to run

1. Install the JDK (version 8 or higher)
2. Keep all files in one folder and open a terminal there
3. Compile and run:

```
javac *.java
java Main
```

## Screenshots

### Main menu, category selection and the first question (instant feedback and live score)
![Menu, categories and first question](screenshots/01-menu-category-question.png)

### More questions (correct/incorrect feedback and live score after every answer)
![Questions and feedback](screenshots/02-questions-feedback.png)

### Final results (score and percentage; missed questions are listed here when answers are wrong)
![Final results](screenshots/03-final-results.png)

## Author

Siraj Ul Umer
